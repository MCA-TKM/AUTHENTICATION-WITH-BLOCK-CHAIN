Provision VMs in Azure cloud using ansible
http://docs.ansible.com/ansible/latest/guide_azure.html

Install Azure CLI 2.0
https://docs.microsoft.com/en-us/cli/azure/install-azure-cli

azure - create or terminate a virtual machine in azure
azure_rm_deployment - Create or destroy Azure Resource Manager template deployments



very good azure ansible playbook -
https://github.com/Blaag/azure/edit/master/create-iperf-vm.yml


Pre-reqs
--------

To use ansible to work with AWS, python library like boto and boto3 must be installed:
-----
sudo pip install azure==2.0.0rc5


Nice to have:
-------------
sudo pip install msrestazure dnspython packaging

