Setup kubernetes
