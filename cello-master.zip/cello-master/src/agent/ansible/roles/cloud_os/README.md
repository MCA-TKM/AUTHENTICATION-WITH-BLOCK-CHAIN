Provision VMs against OpenStack cloud
