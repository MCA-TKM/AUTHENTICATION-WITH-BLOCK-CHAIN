Setup overlay network using flanneld
