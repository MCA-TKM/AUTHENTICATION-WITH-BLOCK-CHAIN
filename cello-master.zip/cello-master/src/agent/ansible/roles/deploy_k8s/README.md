Use kubernetes API to deploy fabric network onto kubernetes
