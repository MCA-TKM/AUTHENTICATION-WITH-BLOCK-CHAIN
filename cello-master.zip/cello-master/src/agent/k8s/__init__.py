# Copyright 2018 (c) VMware, Inc. All Rights Reserved.
#
# SPDX-License-Identifier: Apache-2.0
#
#  This is for agent that interacts with Kubernetes platform using
#  cello-k8s-operator, see github.com/hyperledger/cello-k8s-operator.
