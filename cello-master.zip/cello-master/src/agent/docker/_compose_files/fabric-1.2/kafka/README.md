## Start a network base on kafka

### Quick testing

```bash
$ HLF_MODE=kafka make
```
When the fabric-network fully started, it takes about 30~60s to finish all the test.
