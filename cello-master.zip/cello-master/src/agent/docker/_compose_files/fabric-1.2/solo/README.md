## Start a network base on solo

### Quick testing
```bash
$ HLF_MODE=solo make
```
When the fabric-network fully started, it takes about 30~60s to finish all the test.
