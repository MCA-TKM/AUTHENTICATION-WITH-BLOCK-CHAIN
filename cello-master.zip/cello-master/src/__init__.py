
# Copyright IBM Corp, All Rights Reserved.
#
# SPDX-License-Identifier: Apache-2.0
#
from .version import version, author

__title__ = 'Cello'
__version__ = version
__author__ = author
